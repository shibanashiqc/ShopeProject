<?php return array (
  'admin-category' => 'App\\Http\\Livewire\\AdminCategory',
  'admin-dashboard' => 'App\\Http\\Livewire\\AdminDashboard',
  'admin-prodect-edit' => 'App\\Http\\Livewire\\AdminProdectEdit',
  'admin-product' => 'App\\Http\\Livewire\\AdminProduct',
  'admin-product-create' => 'App\\Http\\Livewire\\AdminProductCreate',
  'product-component' => 'App\\Http\\Livewire\\ProductComponent',
);